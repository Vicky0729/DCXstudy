package com.qkcfamily.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AdminMapper {

	
	//추상 메소드 추가
	
}
