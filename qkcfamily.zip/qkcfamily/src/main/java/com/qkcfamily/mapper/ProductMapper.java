package com.qkcfamily.mapper;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;

import com.qkcfamily.entity.Product;

@Mapper
public interface ProductMapper {

	
	/* public ArrayList<Product> productSearch(String search_str); */
	
}
